from enum import Enum


class TransactionStatus(Enum):
    CHECKED_IN = 1
    CHECKED_OUT = 2
